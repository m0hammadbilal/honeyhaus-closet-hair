document.addEventListener('change',event=>{
 const pick=event.target.closest('[data-variant]');if(!pick)return;
 const choice=pick.selectedOptions[0];const section=pick.closest('.pdp');
 section.querySelector('[data-price]').textContent=choice.dataset.price;
 const image=section.querySelector('.gallery-img');
 if(image && choice.dataset.image){let match=Array.from(section.querySelectorAll('.gallery-img')).find(i=>i.src.split('?')[0]===new URL(choice.dataset.image,location.href).href.split('?')[0]);if(match)section.querySelector('.gallery').prepend(match);}
 const url=new URL(location.href);url.searchParams.set('variant',choice.value);history.replaceState(null,'',url);
});
document.addEventListener('click',e=>{
 const link=e.target.closest('[data-bag]'),drawer=document.getElementById('BagDrawer');
 if(link && drawer && typeof drawer.showModal==='function'){e.preventDefault();drawer.showModal()}
 if(e.target.closest('[data-close]') && drawer)drawer.close();
});
(()=>{
 const home=document.body.classList.contains('is-home');
 if(home){const sync=()=>document.body.classList.toggle('past-top',window.scrollY>40);sync();window.addEventListener('scroll',sync,{passive:true})}
 let saved=[];try{saved=JSON.parse(localStorage.getItem('hh-liked')||'[]');if(!Array.isArray(saved))saved=[]}catch{}
 const syncLikes=()=>document.querySelectorAll('[data-like]').forEach(b=>b.setAttribute('aria-pressed',saved.includes(b.dataset.like)));
 syncLikes();
 document.addEventListener('click',e=>{
  const like=e.target.closest('[data-like]');if(like){const id=like.dataset.like;saved=saved.includes(id)?saved.filter(v=>v!==id):saved.concat(id);try{localStorage.setItem('hh-liked',JSON.stringify(saved))}catch{}syncLikes()}
  const motion=e.target.closest('.motion-toggle');if(motion){const on=motion.closest('.film-stage').classList.toggle('paused');motion.setAttribute('aria-pressed',on);motion.textContent=on?'Play images':'Pause images'}
  const note=e.target.closest('[data-note]');if(note){const track=note.closest('.haus-notes').querySelector('.note-track');const first=track.querySelector('article');if(first)track.scrollBy({left:Number(note.dataset.note)*(first.offsetWidth+18),behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'})}
 });
 document.addEventListener('toggle',e=>{const item=e.target;if(!item.matches?.('[data-step][open]'))return;item.closest('.step-spread').querySelectorAll('[data-step-photo]').forEach(img=>img.hidden=img.dataset.stepPhoto!==item.dataset.step)},true);
 if('IntersectionObserver'in window&&!matchMedia('(prefers-reduced-motion:reduce)').matches){const observer=new IntersectionObserver(items=>items.forEach(i=>{if(i.isIntersecting){i.target.classList.add('is-revealed');observer.unobserve(i.target)}}),{threshold:.08});document.querySelectorAll('main section:not(.opening)').forEach(s=>observer.observe(s))}
})();
